
<button class="btn btn-default delete-user" title="Delete" data-id=<?= $id;?> >
        <i class="far fa-trash-alt "></i>
</button> 

