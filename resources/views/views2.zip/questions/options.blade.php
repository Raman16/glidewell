<p>A.<?= $opt1 ?></p>
<p>B.<?= $opt2 ?></p>
<p>C.<?= $opt3 ?></p>
<p>D.<?= $opt4 ?></p>
