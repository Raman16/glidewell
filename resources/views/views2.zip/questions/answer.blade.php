<?php
   if($answer=='opt1')
     echo $opt1;
   else if($answer=='opt2')
     echo $opt2;
   else if($answer=='opt3')
      echo $opt3;
    else if($answer=='opt4')
      echo $opt4;
    else
      echo $opt5;
?>