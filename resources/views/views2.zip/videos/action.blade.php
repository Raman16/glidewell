<button title="View" class="btn btn-danger edit-video" data-toggle="modal"
        data-id=<?= $id;?>   category=<?= $category_name ?>    data-target="#ModalLoginForm"><i
class="far fa-eye"></i></button>