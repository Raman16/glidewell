<button class="btn btn-danger" title="Active"> 
        <?= ($status==1)?'Active':'Inactive'?> </button>