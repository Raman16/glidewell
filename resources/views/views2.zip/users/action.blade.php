<button class="btn btn-danger edit-user" title="Edit" 
        data-id=<?= $id;?> data-target="#ModalForm">
        <i class="fas fa-pencil-alt" ></i>
</button>

<button class="btn btn-default delete-user" title="Delete" data-id=<?= $id;?> >
        <i class="far fa-trash-alt "></i>
</button> 


<!-- 
<a  data-toggle="tooltip" data-id=<?= $id;?> data-original-title="Edit" class="edit btn btn-success edit-module">
   Edit
</a> -->
<!-- <a href="javascript:void(0)" data-id=<?= $id;?> data-toggle="tooltip" data-original-title="Delete" 
    class="delete btn btn-danger delete-module">
    Delete
</a> -->
